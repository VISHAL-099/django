import base64
from django.core.files.base import ContentFile
from django.shortcuts import render, redirect
from .models import UserSignature

from django.shortcuts import render, redirect
from .models import UserSignature
from .forms import UserSignatureForm
import base64
from django.core.files.base import ContentFile

def save_signature(request):
    if request.method == 'POST':
        form = UserSignatureForm(request.POST)

        if form.is_valid():
            name = form.cleaned_data['name']
            age = form.cleaned_data['age']
            signature_data = request.POST.get('signature')

            if signature_data:
                # Decode the base64 signature image data
                format, imgstr = signature_data.split(';base64,')
                ext = format.split('/')[-1]  # Get the image extension (e.g., png, jpeg)
                signature_image = ContentFile(base64.b64decode(imgstr), name=f'{name}_signature.{ext}')

                # Save the user signature
                user_signature = UserSignature(name=name, age=age, signature=signature_image)
                user_signature.save()

            return redirect('success')

    else:
        form = UserSignatureForm()

    return render(request, 'signature_form.html', {'form': form})

def success(request):
    return render(request, 'success.html')