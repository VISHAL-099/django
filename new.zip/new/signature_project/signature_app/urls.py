from django.urls import path
from . import views

urlpatterns = [
    path('', views.save_signature, name='save_signature'),
    path('success/', views.success, name='success'),  # A simple success view
]
