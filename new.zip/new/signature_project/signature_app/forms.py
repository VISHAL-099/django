from django import forms
from .models import UserSignature

class UserSignatureForm(forms.ModelForm):
    class Meta:
        model = UserSignature
        fields = ['name', 'age', 'signature']  # Only name and age will be filled, signature will be handled in the view

        # Optional: Customizing widgets
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your name'}),
            'age': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter your age'}),
        }
