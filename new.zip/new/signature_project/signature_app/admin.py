from django.contrib import admin
from .models import UserSignature

@admin.register(UserSignature)
class UserSignatureAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'signature')  # Display these fields in the admin list view
    search_fields = ('name', 'age')  # Add search functionality by name and age
